
var language_togglebase = psbase.extend({


	construct: function() {

	
	}
		


	
});




var ps_language_toggle = new language_togglebase();



$(document).ready(function(){


	
});
