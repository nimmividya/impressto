<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'name'	=> 'Language toggle',
	'description'	=> 'simple toggle navigation aid',
	'author'		=> '',
	'admin_menu_section'		=> 'widget',
	'module_type'		=> 'custom'
	
);

$config['module_roleactions'] = array('ACCESSIBLE'=>'Can access this module');


