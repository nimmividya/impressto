<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

// NOTE: Encode this file as UTF8 without BOM (Byte order mark) encoding. PHP supports standard UTF encloding which
// does not support BOM. If this or any other PHP included file is UTF8 encoded WITH BOM, a &#65279 (UTF8 blank space) 
// will be the output on every PHP include call

$lang['skeleton_label'] = 'skeleton';



