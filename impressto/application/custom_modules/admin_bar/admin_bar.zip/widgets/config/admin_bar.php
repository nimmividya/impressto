<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['widget_config'] = array(
	'name'	=> 'Admin Bar',
	'description'	=> 'skeleton_description',
	'author'		=> 'skeleton_author',
	'admin_menu_section'		=> 'widget',
	'module_type'		=> 'custom'
);

$config['module_roleactions'] = array();
