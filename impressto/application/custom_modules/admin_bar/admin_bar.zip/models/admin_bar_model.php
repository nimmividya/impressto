<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin_bar_model extends My_Model{

	
	public function __construct() 
	{

		parent::__construct();
		
	}
	
	
	
	
} //end class